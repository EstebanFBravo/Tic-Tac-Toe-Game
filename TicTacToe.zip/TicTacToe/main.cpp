/***************************************************************************************
Programmer: Esteban Bravo.
Program name: Tic Tac Toe Game.
Purpose: Simple 2 player tic tac toe game that displays the game board accordingly
         to the player's inputs. To win the game you must get 3 slots with your marker.

***************************************************************************************/
#include <iostream>
using namespace std;

//global variables.
char Board[3][3] = {{'1','2','3'}, {'4','5','6'}, {'7','8','9'}};
char MarkerTrack;
int Player;


void BoardDisplay()  // function to print out the board.
{
    cout<< "\n" << Board[0][0] << " | " << Board[0][1]  << " | " << Board[0][2] << endl;
    cout<< "----------\n";

    cout<< "" << Board[1][0] << " | " << Board[1][1]  << " | " << Board[1][2] << endl;
    cout<< "----------\n";

    cout<< "" << Board[2][0] << " | " << Board[2][1]  << " | " << Board[2][2] << endl;
}


void ChangeTurns() //function that allows the game to change turns between players.
{

    if(MarkerTrack == 'x')  //changes the marker from one player to another.
    {
        MarkerTrack = 'o';

    }
    else
    {
        MarkerTrack = 'x';
    }


    if(Player == 1)  //gives the next player a turn.
    {
        Player = 2;
    }
    else
    {
        Player = 1;
    }
}


void UserInput(int slot) //function that inputs the decision of the user into the board.
{
    int row;
    int column;

    if (slot % 3 == 0)       //gets the value for the row
    {
        row = (slot / 3) - 1;
    }
    else
    {
        row = slot / 3;
    }

    if(slot % 3 == 0)    //gets the value for the collumn
    {
        column = 2;
    }
    else
    {
        column = (slot % 3) - 1;
    }

    Board[row][column] = MarkerTrack;  //uses the values found for the row and column as coordinates in order to place the marker.
}


int win() //function that determines a winner.
{
    for(int i = 0; i < 3; i++)  //checks if one of the players won by having the same row or column.
    {
        if(Board[i][0] == Board[i][1] && Board[i][1] == Board[i][2])  //checks the rows(Horizontally).
        {
            return Player;
        }
        if(Board[0][i] == Board[1][i] && Board[1][i] == Board[2][i])  //checks the columns(Vertically).
        {
            return Player;
        }
    }

    if(Board[0][0] == Board[1][1] && Board[1][1] == Board[2][2])  //if slots 1, 5, and 9 are the same then the player wins(/).
    {
        return Player;
    }
    if(Board[0][2] == Board[1][1] && Board[1][1] == Board[2][0])  //if slots 3, 5, and 7 are the same then the player wins(\).
    {
        return Player;
    }
    return 0;
}


int main() //Main function that makes up the game.
{
    int won;
    char MarkerP1;

    //Asks the desired marker from the user thats going to be Player 1.
    cout << "Player 1 choose a marker (x or o): ";
    cin >> MarkerP1;

    while(MarkerP1 != 'x')  //Checks for bad inputs and wont proceed until either x or o is entered.
    {
            if(MarkerP1 == 'o') //Makes it so o is an exception and breaks out of the loop.
            {
                break;
            }
            cout << MarkerP1 << " is not one of the markers provided please try again(check if your capitalize key is on)\n" << endl;
            cout << "choose a valid marker (x or o): ";
            cin >> MarkerP1;
    }

    cout << "\nPlayer 2 you will be the opposite marker\n";
    cout << "\nInstructions: To choose your slot, type in the number that matches the desired slot.";
    Player = 1;
    MarkerTrack = MarkerP1;
    BoardDisplay();

    for(int i = 0; i < 9; i++)  //takes in the player's input and calls in the other functions to modify accordingly.
    {
        int slot;
        cout << "\nPlayer " << Player << " enter the slot you choose: ";
        cin >> slot;
        UserInput(slot);
        BoardDisplay();
        won = win();
        if(won == 1)  //If player 1 has 3 consecutive slots with his marker then he's declared the winner. Then it breaks out of the loop
        {
            cout << "\nPlayer 1 wins!\n";
            break;
        }
        if(won == 2)  //If player 2 has 3 consecutive slots with his marker then he's declared the winner. Then it breaks out of the loop
        {
            cout << "\nPlayer 2 wins!\n";
            break;
        }

        ChangeTurns();  //Calls this function in order to give the other player a go.
    }

    if(won == 0)
    {
        cout << "\nIts a tie!\n"; //If none of the players have 3 consecutive slots with their marker then a tie its declared.
    }
    cout << "\nThanks for playing!!\n";
}
